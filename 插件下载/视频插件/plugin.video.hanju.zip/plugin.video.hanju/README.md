# plugin.video.hanju

** 韩剧视频插件(Kodi) ***

韩剧视频插件（Kodi）基于爬虫技术，以Kodi为平台进行计算并抓取第三方资源网站数据采集自动拓扑生成的视频内容，本插件开发之初的目的是用以学习Kodi插件开发及python技术整合，请勿用于其他用途。

=========================   

![截图1](./resources/1.png)

![截图2](./resources/2.png)

![截图3](./resources/3.png)
