# plugin.video.duolasousuo

## 哆啦搜索（Kodi视频插件）

``` 

本視頻插件基於第三方資源站api進行模擬爬行構建拓撲，僅適用於Python開發測試和練習，請勿用於其他用途。

```

> 如何更換其他第三方資源站數據接口？

在設置中，修改【內置搜索引擎接口】，可以修改為你所需要的資源站數據接口。

資源站json接口：例如“https://api.123.com/api.php/provide/vod/?ac=list” 則只需要接口為 “https://api.123.com/api.php/provide/vod/”
將 https://api.123.com/api.php/provide/vod/ 替換系統內置的接口地址即可。

> 如何啟用雲端引擎接口？

在設置中，開啟【使用雲端搜索接口】即可
